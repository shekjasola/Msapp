package com.example.taskdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskDashboardApplicationTests {

    @Test
    void contextLoads() {
    }

}
