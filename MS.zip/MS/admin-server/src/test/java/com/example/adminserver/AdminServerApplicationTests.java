package com.example.adminserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
